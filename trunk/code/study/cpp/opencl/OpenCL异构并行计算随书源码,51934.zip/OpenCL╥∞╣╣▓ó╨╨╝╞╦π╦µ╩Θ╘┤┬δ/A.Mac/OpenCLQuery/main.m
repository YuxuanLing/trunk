//
//  main.m
//  OpenCLQuery
//
//  Created by Zenny Chen on 13-9-9.
//  Copyright (c) 2013年 Zenny Chen. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
