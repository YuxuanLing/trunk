# util
my own util library for toy programming

I don't think you want to use it in your code
