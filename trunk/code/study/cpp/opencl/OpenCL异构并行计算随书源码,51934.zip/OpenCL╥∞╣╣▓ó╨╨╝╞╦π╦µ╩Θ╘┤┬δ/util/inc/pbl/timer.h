#ifndef H_TIMER
#define H_TIMER

#include "timer/CUDATimer.h"
#include "timer/CPUTimer.h"

#endif
