#pragma once
    #include "random/CPURandom.h"
    #include "random/CUDARandom.h"
