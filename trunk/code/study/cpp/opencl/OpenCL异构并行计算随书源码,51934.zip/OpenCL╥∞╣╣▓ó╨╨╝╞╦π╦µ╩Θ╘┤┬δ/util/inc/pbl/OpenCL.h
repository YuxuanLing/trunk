#ifndef H_OPENCL
#define H_OPENCL

#include "common.h"

#include "OpenCL/oclutil.h"

#endif
