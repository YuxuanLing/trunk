#pragma once

#ifdef __cplusplus
#include "pictureFormat/PPMReadWrite.h"
#include "pictureFormat/BMPReadWrite.h"
#endif
