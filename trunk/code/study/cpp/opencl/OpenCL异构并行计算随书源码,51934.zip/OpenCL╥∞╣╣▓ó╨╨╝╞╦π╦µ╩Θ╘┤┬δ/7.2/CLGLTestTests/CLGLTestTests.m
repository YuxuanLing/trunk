//
//  CLGLTestTests.m
//  CLGLTestTests
//
//  Created by Zenny Chen on 14-8-1.
//  Copyright (c) 2014年 Adwo. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface CLGLTestTests : XCTestCase

@end

@implementation CLGLTestTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
