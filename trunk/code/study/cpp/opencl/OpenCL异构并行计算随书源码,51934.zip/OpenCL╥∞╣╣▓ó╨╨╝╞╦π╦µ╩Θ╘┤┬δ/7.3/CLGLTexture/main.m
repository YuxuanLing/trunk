//
//  main.m
//  CLGLTexture
//
//  Created by Zenny Chen on 15/5/15.
//  Copyright (c) 2015年 GreenGames Studio. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
