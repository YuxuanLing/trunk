#define IDM_SYSMENU_FULL_WINDOW      16
#define IDM_SYSMENU_STAY_ON_TOP      32
#define IDI_APPICON                 100
