//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CalUser.rc
//
#define IDD_CALUSER_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_CALENDAR                    1001
#define IDC_YEAR                        1004
#define IDC_MONTH                       1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
