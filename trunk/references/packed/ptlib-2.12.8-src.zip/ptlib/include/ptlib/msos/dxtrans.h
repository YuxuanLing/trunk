/* dxtrans.h dummy header. Required by vidinput_directx2.cxx which includes
   qedit.h which in turn includes dxtrans.h which the SDK does not provide!
 */
