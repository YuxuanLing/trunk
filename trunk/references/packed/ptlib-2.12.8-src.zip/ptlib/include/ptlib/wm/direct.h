//////////////////////////////////////////////////////
//
// VisualStudio 2005 PWLib Port, 
// (c) 2007 Dinsk.net
// developer@dinsk.net 
//
//////////////////////////////////////////////////////
//
// (c) Yuri Kiryanov, yuri@kiryanov.com
// for Openh323, www.Openh323.org
//
// Windows CE Port
// Extra header file 
// 

#include "stdlibx.h"

