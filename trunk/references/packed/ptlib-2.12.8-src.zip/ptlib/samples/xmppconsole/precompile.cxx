/*
 * precompile.cxx
 *
 * PWLib application source file for XMPPConsole
 *
 * Originally from the XMPPTest module, copied here by Derek Smithies.
 *
 * Precompiled header generation file.
 *
 * Copyright 2004 Reitek S.p.A.
 *
 * $Revision: 20385 $
 * $Author: rjongbloed $
 * $Date: 2008-06-04 05:40:38 -0500 (Wed, 04 Jun 2008) $
 */

#include <ptlib.h>


// End of File ///////////////////////////////////////////////////////////////
