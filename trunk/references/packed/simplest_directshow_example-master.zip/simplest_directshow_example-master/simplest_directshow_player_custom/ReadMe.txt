﻿最简单的基于DirectShow的视频播放器（Custom）
Simplest DirectShow Player (Custom)

雷霄骅 Lei Xiaohua
leixiaohua1020@126.com
中国传媒大学/数字电视技术
Communication University of China / Digital TV Technology
http://blog.csdn.net/leixiaohua1020

本程序是一个简单的基于DirectShow的视频播放器。该播放器通过逐个添加
滤镜并连接这些滤镜实现了视频的播放。适合初学者学习DirectShow。

This software is a simple video player based on DirectShow.
It Add DirectShow Filter Manually and Link the Pins of these filters
to play videos.Suitable for the beginner of DirectShow.
