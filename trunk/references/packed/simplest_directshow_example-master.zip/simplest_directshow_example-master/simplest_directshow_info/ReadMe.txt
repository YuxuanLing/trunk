﻿最简单的Directshow信息显示例子
Simplest DirectShow Info

雷霄骅 Lei Xiaohua
leixiaohua1020@126.com
中国传媒大学/数字电视技术
Communication University of China / Digital TV Technology
http://blog.csdn.net/leixiaohua1020

本程序是一段获取DirectShow滤镜信息的代码。通过本代码可以获得
DirectShow滤镜信息。适合初学者学习DirectShow。

This code can be used to get Directshow Filter's information.
Suitable for the beginner of DirectShow.