#ifndef _ICAMERACAPTUER_H_
#define _ICAMERACAPTUER_H_

//#include "DllManager.h"
#include <list>

struct FORMAT_INFO
{
	int width;
	int height;
};

struct CAMERA_INFO
{
	int id;
	char name[128];
	std::list<FORMAT_INFO> flist;
};

class ICameraCaptuer
{
public:
    ICameraCaptuer() {}
    virtual ~ICameraCaptuer() {}

	virtual std::list<CAMERA_INFO> QueryCameraList() = 0;

    virtual bool OpenCamera(int nCamID, int nWidth, int nHeight) = 0;

    virtual void CloseCamera() = 0;

    virtual int GetWidth() = 0;

    virtual int GetHeight() = 0;

    virtual unsigned  char * QueryFrame() = 0;

    virtual unsigned  char * QueryFrame_rgb() = 0;

	virtual int CameraCount() = 0;

	virtual int CameraName(int nCamID, char* sName, int nBufferSize) = 0;
};

class CamCaptuerMgr
{
public:
    static ICameraCaptuer* GetCamCaptuer();

    static void Destory(ICameraCaptuer* pCamCaptuer);
};

#endif

