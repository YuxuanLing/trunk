#include "ICameraCaptuer.h"
#include "CameraDS.h"

//��һ�ɼ��࣬�������� �ͱ�����ʾ

ICameraCaptuer* m_gpCamera = NULL;

ICameraCaptuer* CamCaptuerMgr::GetCamCaptuer() 
{ 
	if (NULL == m_gpCamera)
	{
		m_gpCamera =  new CCameraDS; 
	}
	return m_gpCamera;
    
}

void CamCaptuerMgr::Destory(ICameraCaptuer* pCamCaptuer) 
{ 
	if (m_gpCamera && m_gpCamera == pCamCaptuer)
	{
       delete  m_gpCamera; 
	   m_gpCamera = NULL;
	}
	pCamCaptuer = NULL;
    
  
}


